import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "@/styles/globals.css";
import { Analytics } from "@vercel/analytics/react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Call George - Voice-Activated Scheduling Assistant",
  description:
    "Experience seamless voice-powered appointment scheduling with Call George. Our intelligent assistant integrates with Calendly to manage your bookings using natural conversation. Try the future of meeting scheduling today!",
  keywords: [
    "AI scheduling assistant",
    "voice-activated booking",
    "Calendly integration",
    "voice AI technology",
    "meeting scheduler",
    "smart calendar management",
  ],
  icons: {
    icon: "/george-icon-blue.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen flex flex-col`}
      >
        <Navbar />
        <main className="flex-grow">{children}</main>
        <Footer />
        <Analytics />
      </body>
    </html>
  );
}
